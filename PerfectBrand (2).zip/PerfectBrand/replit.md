# Perfect Marketing Company Website

## Overview

This is a marketing company website for Perfect Marketing Company Ltd (PMC), a professional marketing services firm based in Kigali, Rwanda. The website serves as a digital presence to showcase their services including marketing, sales promotions, merchandising, employee recruitment, and market storm services. The site is designed to elevate brand perception and attract potential clients looking for comprehensive marketing solutions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Static HTML Website**: Single-page application built with vanilla HTML, CSS, and JavaScript
- **Responsive Design**: Mobile-first approach using Tailwind CSS framework for consistent styling across devices
- **Component-Based Structure**: Modular HTML sections for navigation, hero, services, about, and contact areas
- **Progressive Enhancement**: Core functionality works without JavaScript, enhanced with interactive features

### Styling and Design System
- **Tailwind CSS Framework**: Utility-first CSS framework loaded via CDN for rapid development
- **Custom Color Palette**: Brand-specific colors (PMC blue: #1e40af, PMC pink: #ec4899) defined in Tailwind config
- **Typography System**: Inter font family for modern, readable text across all screen sizes
- **Animation Library**: Custom CSS animations for fade-in and slide-in effects to enhance user experience

### Performance Optimization
- **CDN Resources**: External libraries (Tailwind, Font Awesome, Google Fonts) loaded from CDNs for faster delivery
- **Minimal JavaScript**: Lightweight client-side scripting for interactive elements and smooth scrolling
- **Optimized Images**: Image optimization strategy for fast loading times
- **Custom Scrollbar**: Branded scrollbar design matching company color scheme

## External Dependencies

### CSS Frameworks and Libraries
- **Tailwind CSS**: Utility-first CSS framework (v3.x) via CDN
- **Font Awesome**: Icon library (v6.4.0) for scalable vector icons
- **Google Fonts**: Inter font family for consistent typography

### Content Delivery Networks
- **Tailwind CSS CDN**: https://cdn.tailwindcss.com
- **Font Awesome CDN**: https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css
- **Google Fonts API**: https://fonts.googleapis.com/css2 for web font delivery

### SEO and Metadata
- **Meta Tags**: Comprehensive SEO meta tags for search engine optimization
- **Structured Data**: Proper HTML semantic structure for better search engine understanding
- **Local Business Focus**: Geo-targeted content for Kigali, Rwanda market